@echo off
chcp 65001 >nul
echo ===== doortrim-atlas 오프라인 설치 =====
cd /d "%~dp0"
for /f "tokens=2 delims= " %%v in ('python --version 2^>^&1') do set PYVER=%%v
for /f "tokens=1,2 delims=." %%a in ("%PYVER%") do set PYMM=%%a.%%b
echo 파이썬 버전: %PYVER%  (휠 폴더: wheels\py%PYMM%)
if not exist "wheels\py%PYMM%" (
  echo [오류] wheels\py%PYMM% 폴더가 없습니다. 지원 버전: 3.10, 3.11, 3.12
  echo        집에서 다음 명령으로 받아 추가하세요:
  echo        python -m pip download -r requirements.txt pywin32 -d wheels\py%PYMM% --platform win_amd64 --python-version %PYMM% --only-binary=:all:
  pause & exit /b 1
)
python -m pip install --no-index --find-links "wheels\py%PYMM%" -r requirements.txt pywin32
if errorlevel 1 ( echo [오류] 설치 실패. INSTALL_OFFLINE.md 의 '자주 겪는 문제'를 보세요. & pause & exit /b 1 )
python -c "import numpy, scipy, sklearn, trimesh, matplotlib; print('설치 확인 OK')"
echo.
echo 설치가 끝났습니다. 동작 확인:  python -m doortrim_atlas demo --out demo_out
pause
